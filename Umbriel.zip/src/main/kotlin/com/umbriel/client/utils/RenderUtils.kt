package com.umbriel.client.utils
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.render.*
import org.joml.Matrix4f
object RenderUtils {
    fun drawRoundedRect(context: DrawContext, x: Int, y: Int, width: Int, height: Int, radius: Int, color: Int) {
        val alpha = ((color shr 24) and 0xFF) / 255f; val red = ((color shr 16) and 0xFF) / 255f; val green = ((color shr 8) and 0xFF) / 255f; val blue = (color and 0xFF) / 255f
        context.fill(x + radius, y, x + width - radius, y + height, color); context.fill(x, y + radius, x + radius, y + height - radius, color); context.fill(x + width - radius, y + radius, x + width, y + height - radius, color)
        val matrix = context.matrices.peek().positionMatrix; val tessellator = Tessellator.getInstance(); val buffer = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR)
        drawRoundedCorner(matrix, buffer, x + radius.toFloat(), y + radius.toFloat(), radius.toFloat(), red, green, blue, alpha, 180f, 270f)
        drawRoundedCorner(matrix, buffer, x + width - radius.toFloat(), y + radius.toFloat(), radius.toFloat(), red, green, blue, alpha, 270f, 360f)
        drawRoundedCorner(matrix, buffer, x + width - radius.toFloat(), y + height - radius.toFloat(), radius.toFloat(), red, green, blue, alpha, 0f, 90f)
        drawRoundedCorner(matrix, buffer, x + radius.toFloat(), y + height - radius.toFloat(), radius.toFloat(), red, green, blue, alpha, 90f, 180f)
        BufferRenderer.drawWithGlobalProgram(buffer.end())
    }
    private fun drawRoundedCorner(matrix: Matrix4f, buffer: BufferBuilder, centerX: Float, centerY: Float, radius: Float, red: Float, green: Float, blue: Float, alpha: Float, startAngle: Float, endAngle: Float) {
        buffer.vertex(matrix, centerX, centerY, 0f).color(red, green, blue, alpha)
        for (i in 0..16) { val angle = Math.toRadians((startAngle + (endAngle - startAngle) * i / 16).toDouble()); val x = centerX + (Math.cos(angle) * radius).toFloat(); val y = centerY + (Math.sin(angle) * radius).toFloat(); buffer.vertex(matrix, x, y, 0f).color(red, green, blue, alpha) }
    }
}

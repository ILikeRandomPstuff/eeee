package com.umbriel.client.utils
import java.io.File
object ConfigManager {
    private val configDir = File("config/umbriel")
    private val configFile = File(configDir, "client.txt")
    private var isFirstLaunch = true
    fun init() { if (!configDir.exists()) configDir.mkdirs(); isFirstLaunch = !configFile.exists(); if (isFirstLaunch) { configFile.createNewFile(); configFile.writeText("first_launch=false") } }
    fun isFirstLaunch() = isFirstLaunch
    fun setFirstLaunchComplete() { isFirstLaunch = false }
}

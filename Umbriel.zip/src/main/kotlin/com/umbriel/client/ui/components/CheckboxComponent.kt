package com.umbriel.client.ui.components
import com.umbriel.client.ui.animation.Easing
import com.umbriel.client.utils.RenderUtils
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
class CheckboxComponent(private val name: String, private var checked: Boolean) : UIComponent {
    private var hoverAlpha = 0f
    private var checkAnimation = if (checked) 1f else 0f
    override fun getHeight() = 22
    override fun render(context: DrawContext, x: Int, y: Int, width: Int, mouseX: Int, mouseY: Int, alpha: Float) {
        val mc = MinecraftClient.getInstance()
        val isHovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + getHeight()
        hoverAlpha = Easing.lerp(hoverAlpha, if (isHovered) 1f else 0f, 0.15f)
        checkAnimation = Easing.lerp(checkAnimation, if (checked) 1f else 0f, 0.12f)
        RenderUtils.drawRoundedRect(context, x, y, width, getHeight(), 8, UColor.withAlpha(UColor.BG_DARK, (alpha * hoverAlpha * 30).toInt()))
        val boxX = x + 8
        val boxY = y + 6
        val boxSize = 10
        val boxColor = UColor.interpolate(UColor.BG_PANEL, UColor.getAccentDark(), checkAnimation * 0.5f)
        RenderUtils.drawRoundedRect(context, boxX, boxY, boxSize, boxSize, 5, UColor.withAlpha(boxColor, (alpha * 255).toInt()))
        if (checkAnimation > 0.01f) {
            val checkSize = (boxSize * 0.6f * checkAnimation).toInt()
            RenderUtils.drawRoundedRect(context, boxX + (boxSize - checkSize) / 2, boxY + (boxSize - checkSize) / 2, checkSize, checkSize, 3, UColor.withAlpha(UColor.getAccent(), (alpha * 255 * checkAnimation).toInt()))
        }
        context.drawText(mc.textRenderer, name, boxX + boxSize + 8, y + 7, UColor.withAlpha(UColor.TEXT, (alpha * 255).toInt()), false)
    }
    override fun handleClick(mouseX: Int, mouseY: Int, x: Int, y: Int, width: Int, button: Int): Boolean {
        if (button == 0 && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + getHeight()) {
            checked = !checked
            return true
        }
        return false
    }
}

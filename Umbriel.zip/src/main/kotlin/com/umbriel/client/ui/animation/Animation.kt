package com.umbriel.client.ui.animation
class Animation(private val duration: Long, private val callback: (Float) -> Unit, private val easingFunction: (Float) -> Float = Easing::easeOutCubic) {
    private val startTime = System.currentTimeMillis()
    fun update(): Boolean { val progress = ((System.currentTimeMillis() - startTime).toFloat() / duration).coerceIn(0f, 1f); callback(easingFunction(progress)); return progress >= 1f }
}

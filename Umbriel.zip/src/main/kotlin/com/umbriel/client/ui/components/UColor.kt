package com.umbriel.client.ui.components
object UColor {
    const val BG_DARK = 0x0A0A0A
    const val BG_PANEL = 0x141414
    const val BG_HOVER = 0x1E1E1E
    const val TEXT = 0xFFFFFF
    const val TEXT_DIM = 0x888888
    const val BORDER = 0x2A2A2A
    var currentTheme = Theme.CYAN
    private var rainbowHue = 0f
    enum class Theme(val primary: Int, val secondary: Int, val displayName: String) {
        CYAN(0x00E5FF, 0x00A0B0, "Cyan"), PURPLE(0xB64CFF, 0x8A2BE2, "Purple"), RED(0xFF4444, 0xCC0000, "Red"),
        GREEN(0x44FF44, 0x00CC00, "Green"), ORANGE(0xFFA500, 0xFF6600, "Orange"), PINK(0xFF69B4, 0xFF1493, "Pink"),
        RAINBOW(0xFFFFFF, 0xFFFFFF, "Rainbow")
    }
    fun updateRainbow() { rainbowHue += 0.5f; if (rainbowHue >= 360f) rainbowHue = 0f }
    fun getAccent(): Int = if (currentTheme == Theme.RAINBOW) hsvToRgb(rainbowHue, 1f, 1f) else currentTheme.primary
    fun getAccentDark(): Int = if (currentTheme == Theme.RAINBOW) hsvToRgb((rainbowHue + 30f) % 360f, 1f, 0.8f) else currentTheme.secondary
    fun hsvToRgb(h: Float, s: Float, v: Float): Int {
        val c = v * s; val x = c * (1 - Math.abs(((h / 60f) % 2) - 1)); val m = v - c
        val (r1, g1, b1) = when { h < 60 -> Triple(c, x, 0f); h < 120 -> Triple(x, c, 0f); h < 180 -> Triple(0f, c, x); h < 240 -> Triple(0f, x, c); h < 300 -> Triple(x, 0f, c); else -> Triple(c, 0f, x) }
        return (((r1 + m) * 255).toInt() shl 16) or (((g1 + m) * 255).toInt() shl 8) or ((b1 + m) * 255).toInt()
    }
    fun withAlpha(color: Int, alpha: Int): Int = (alpha shl 24) or (color and 0xFFFFFF)
    fun interpolate(color1: Int, color2: Int, ratio: Float): Int {
        val r = ((color1 shr 16 and 0xFF) + ((color2 shr 16 and 0xFF) - (color1 shr 16 and 0xFF)) * ratio).toInt()
        val g = ((color1 shr 8 and 0xFF) + ((color2 shr 8 and 0xFF) - (color1 shr 8 and 0xFF)) * ratio).toInt()
        val b = ((color1 and 0xFF) + ((color2 and 0xFF) - (color1 and 0xFF)) * ratio).toInt()
        return (r shl 16) or (g shl 8) or b
    }
}

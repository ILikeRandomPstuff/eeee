package com.umbriel.client.ui.components
import net.minecraft.client.gui.DrawContext
interface UIComponent {
    fun render(context: DrawContext, x: Int, y: Int, width: Int, mouseX: Int, mouseY: Int, alpha: Float)
    fun handleClick(mouseX: Int, mouseY: Int, x: Int, y: Int, width: Int, button: Int): Boolean
    fun getHeight(): Int = 20
}

package com.umbriel.client.ui.components
import com.umbriel.client.UmbrielClient
import com.umbriel.client.utils.RenderUtils
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
object TopBar {
    private var themeMenuOpen = false
    fun render(context: DrawContext, width: Int, alpha: Float) {
        UColor.updateRainbow()
        val mc = MinecraftClient.getInstance()
        val barHeight = 26
        RenderUtils.drawRoundedRect(context, 0, 0, width, barHeight, 0, UColor.withAlpha(UColor.BG_PANEL, (alpha * 255).toInt()))
        context.fill(0, barHeight - 2, width, barHeight, UColor.withAlpha(UColor.getAccent(), (alpha * 200).toInt()))
        if (UmbrielClient.showWatermark) {
            val watermark = "UMBRIEL v2.0"
            context.drawText(mc.textRenderer, watermark, 10, 9, UColor.withAlpha(UColor.getAccent(), (alpha * 255).toInt()), true)
        }
        var buttonX = width - 10
        val buttons = listOf("Panic", "Themes", "Font", "Watermark")
        buttons.forEach { btn ->
            val btnWidth = mc.textRenderer.getWidth(btn) + 14
            buttonX -= btnWidth + 5
            RenderUtils.drawRoundedRect(context, buttonX, 5, btnWidth, 18, 9, UColor.withAlpha(UColor.BG_HOVER, (alpha * 200).toInt()))
            context.drawText(mc.textRenderer, btn, buttonX + 7, 9, UColor.withAlpha(UColor.TEXT, (alpha * 255).toInt()), false)
        }
        if (themeMenuOpen) {
            val menuX = width - 200
            val menuY = barHeight + 5
            val menuWidth = 180
            val menuHeight = UColor.Theme.values().size * 24 + 10
            RenderUtils.drawRoundedRect(context, menuX, menuY, menuWidth, menuHeight, 8, UColor.withAlpha(UColor.BG_PANEL, (alpha * 255).toInt()))
            context.drawText(mc.textRenderer, "Select Theme", menuX + 10, menuY + 8, UColor.withAlpha(UColor.TEXT, (alpha * 255).toInt()), false)
            UColor.Theme.values().forEachIndexed { index, theme ->
                val themeY = menuY + 24 + index * 24
                val isSelected = UColor.currentTheme == theme
                RenderUtils.drawRoundedRect(context, menuX + 5, themeY, menuWidth - 10, 22, 8, UColor.withAlpha(if (isSelected) UColor.BG_HOVER else UColor.BG_DARK, (alpha * 200).toInt()))
                if (isSelected) context.fill(menuX + 5, themeY, menuX + 9, themeY + 22, UColor.withAlpha(theme.primary, (alpha * 255).toInt()))
                context.drawText(mc.textRenderer, theme.displayName, menuX + 15, themeY + 7, UColor.withAlpha(if (isSelected) theme.primary else UColor.TEXT, (alpha * 255).toInt()), false)
            }
        }
    }
    fun handleClick(mouseX: Int, mouseY: Int, width: Int): Boolean {
        val mc = MinecraftClient.getInstance()
        val barHeight = 26
        if (mouseY > barHeight) {
            if (themeMenuOpen) {
                val menuX = width - 200
                val menuY = barHeight + 5
                val menuWidth = 180
                UColor.Theme.values().forEachIndexed { index, theme ->
                    val themeY = menuY + 24 + index * 24
                    if (mouseX >= menuX + 5 && mouseX <= menuX + menuWidth - 5 && mouseY >= themeY && mouseY <= themeY + 22) {
                        UColor.currentTheme = theme
                        themeMenuOpen = false
                        return true
                    }
                }
                themeMenuOpen = false
            }
            return false
        }
        var buttonX = width - 10
        val buttons = listOf("Panic", "Themes", "Font", "Watermark")
        buttons.forEach { btn ->
            val btnWidth = mc.textRenderer.getWidth(btn) + 14
            buttonX -= btnWidth + 5
            if (mouseX >= buttonX && mouseX <= buttonX + btnWidth && mouseY >= 5 && mouseY <= 23) {
                when (btn) {
                    "Panic" -> UmbrielClient.panic()
                    "Themes" -> themeMenuOpen = !themeMenuOpen
                    "Font" -> UmbrielClient.fontScale = if (UmbrielClient.fontScale >= 1.5f) 1.0f else UmbrielClient.fontScale + 0.1f
                    "Watermark" -> UmbrielClient.showWatermark = !UmbrielClient.showWatermark
                }
                return true
            }
        }
        return false
    }
}

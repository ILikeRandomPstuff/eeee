package com.umbriel.client.ui.screens
import com.umbriel.client.UmbrielClient
import com.umbriel.client.ui.components.*
import com.umbriel.client.ui.animation.AnimationManager
import com.umbriel.client.ui.animation.Easing
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.gui.screen.Screen
import net.minecraft.text.Text
import org.lwjgl.glfw.GLFW
class UmbrielMenuScreen : Screen(Text.literal("Umbriel")) {
    private val categories = mutableListOf<CategoryPanel>()
    private val animationManager = AnimationManager()
    private var fadeAlpha = 0f
    private var draggedCategory: CategoryPanel? = null
    init { setupCategories(); animationManager.animate(200, Easing::easeOutCubic) { fadeAlpha = it } }
    private fun setupCategories() {
        val combat = CategoryPanel("Combat", 0)
        combat.addModule(ModuleButton("KillAura", false).apply { 
            settings.add(SliderComponent("Range", 4.2f, 3.0f, 6.0f, 0.1f))
            settings.add(SliderComponent("APS", 12.0f, 1.0f, 20.0f, 1.0f))
            settings.add(CheckboxComponent("Auto Block", true))
            settings.add(CheckboxComponent("Raycast", false))
            settings.add(DropdownComponent("Mode", listOf("Single", "Multi", "Switch")))
        })
        combat.addModule(ModuleButton("Velocity", true).apply { settings.add(SliderComponent("Horizontal", 0f, 0f, 100f, 5f)); settings.add(SliderComponent("Vertical", 0f, 0f, 100f, 5f)) })
        combat.addModule(ModuleButton("Criticals", false))
        combat.addModule(ModuleButton("AutoClicker", false))
        combat.addModule(ModuleButton("Reach", false))
        combat.addModule(ModuleButton("AntiKnockback", false))
        combat.addModule(ModuleButton("BackTrack", false))
        combat.addModule(ModuleButton("HitBox", false))
        combat.addModule(ModuleButton("AutoPot", false))
        combat.addModule(ModuleButton("BowAimbot", false))
        combat.addModule(ModuleButton("SuperKnockback", false))
        combat.addModule(ModuleButton("TimerRange", false))
        combat.addModule(ModuleButton("AutoSoup", false))
        combat.addModule(ModuleButton("AutoTotem", false))
        combat.addModule(ModuleButton("Regen", false))
        combat.addModule(ModuleButton("Trigger", false))
        combat.addModule(ModuleButton("AimAssist", false))
        combat.addModule(ModuleButton("WTap", false))
        combat.addModule(ModuleButton("STap", false))
        categories.add(combat)
        
        val movement = CategoryPanel("Movement", 1)
        movement.addModule(ModuleButton("Sprint", true))
        movement.addModule(ModuleButton("Speed", false))
        movement.addModule(ModuleButton("Fly", false))
        movement.addModule(ModuleButton("NoFall", false))
        movement.addModule(ModuleButton("Jesus", false))
        movement.addModule(ModuleButton("Spider", false))
        movement.addModule(ModuleButton("HighJump", false))
        movement.addModule(ModuleButton("LongJump", false))
        movement.addModule(ModuleButton("AirJump", false))
        movement.addModule(ModuleButton("NoSlow", false))
        movement.addModule(ModuleButton("Strafe", false))
        movement.addModule(ModuleButton("Sneak", false))
        movement.addModule(ModuleButton("Glide", false))
        movement.addModule(ModuleButton("ElytraFly", false))
        movement.addModule(ModuleButton("Step", false))
        movement.addModule(ModuleButton("Parkour", false))
        movement.addModule(ModuleButton("SafeWalk", false))
        movement.addModule(ModuleButton("WallClimb", false))
        movement.addModule(ModuleButton("AntiVoid", false))
        movement.addModule(ModuleButton("IceSpeed", false))
        movement.addModule(ModuleButton("Slippy", false))
        movement.addModule(ModuleButton("BugUp", false))
        movement.addModule(ModuleButton("ReverseStep", false))
        movement.addModule(ModuleButton("KeepSprint", false))
        movement.addModule(ModuleButton("AirStuck", false))
        movement.addModule(ModuleButton("Bounce", false))
        movement.addModule(ModuleButton("FastFall", false))
        movement.addModule(ModuleButton("Dolphin", false))
        movement.addModule(ModuleButton("NoWeb", false))
        movement.addModule(ModuleButton("FastLadder", false))
        categories.add(movement)
        
        val render = CategoryPanel("Render", 2)
        render.addModule(ModuleButton("ESP", true).apply { settings.add(CheckboxComponent("Box", true)); settings.add(CheckboxComponent("Health", true)); settings.add(SliderComponent("Width", 2f, 1f, 5f, 0.5f)) })
        render.addModule(ModuleButton("Tracers", false))
        render.addModule(ModuleButton("Nametags", true))
        render.addModule(ModuleButton("Fullbright", false))
        render.addModule(ModuleButton("Chams", false))
        render.addModule(ModuleButton("XRay", false))
        render.addModule(ModuleButton("Breadcrumbs", false))
        render.addModule(ModuleButton("ItemESP", false))
        render.addModule(ModuleButton("StorageESP", false))
        render.addModule(ModuleButton("Trajectories", false))
        render.addModule(ModuleButton("Freecam", false))
        render.addModule(ModuleButton("NoRender", false))
        render.addModule(ModuleButton("Crosshair", false))
        render.addModule(ModuleButton("HUD", true))
        render.addModule(ModuleButton("BlockOverlay", false))
        render.addModule(ModuleButton("CameraClip", false))
        render.addModule(ModuleButton("Animations", false))
        render.addModule(ModuleButton("Glint", false))
        render.addModule(ModuleButton("HoleESP", false))
        render.addModule(ModuleButton("Search", false))
        render.addModule(ModuleButton("LogoutSpots", false))
        render.addModule(ModuleButton("PopChams", false))
        render.addModule(ModuleButton("Skeleton", false))
        render.addModule(ModuleButton("Trails", false))
        render.addModule(ModuleButton("CrystalChams", false))
        render.addModule(ModuleButton("NoFOV", false))
        render.addModule(ModuleButton("NoHurtCam", false))
        render.addModule(ModuleButton("ViewModel", false))
        render.addModule(ModuleButton("HandChams", false))
        render.addModule(ModuleButton("EnchantColor", false))
        categories.add(render)
        
        val player = CategoryPanel("Player", 3)
        player.addModule(ModuleButton("InvManager", false))
        player.addModule(ModuleButton("AutoTool", false))
        player.addModule(ModuleButton("NoRotate", false))
        player.addModule(ModuleButton("Scaffold", false))
        player.addModule(ModuleButton("Eagle", false))
        player.addModule(ModuleButton("Tower", false))
        player.addModule(ModuleButton("Breaker", false))
        player.addModule(ModuleButton("AutoRespawn", false))
        player.addModule(ModuleButton("FastBow", false))
        player.addModule(ModuleButton("FastEat", false))
        player.addModule(ModuleButton("NoJumpDelay", false))
        player.addModule(ModuleButton("Blink", false))
        player.addModule(ModuleButton("Spoofer", false))
        player.addModule(ModuleButton("FastUse", false))
        player.addModule(ModuleButton("AntiHunger", false))
        player.addModule(ModuleButton("AutoFish", false))
        player.addModule(ModuleButton("ChestStealer", false))
        player.addModule(ModuleButton("FastPlace", true))
        player.addModule(ModuleButton("InvWalk", false))
        player.addModule(ModuleButton("NoSwing", false))
        player.addModule(ModuleButton("AutoEat", false))
        player.addModule(ModuleButton("Refill", false))
        player.addModule(ModuleButton("AutoMine", false))
        player.addModule(ModuleButton("FastBreak", false))
        player.addModule(ModuleButton("AntiCactus", false))
        player.addModule(ModuleButton("AntiWeb", false))
        player.addModule(ModuleButton("NoSlowBreak", false))
        player.addModule(ModuleButton("GhostHand", false))
        player.addModule(ModuleButton("Reach", false))
        categories.add(player)
        
        val exploit = CategoryPanel("Exploit", 4)
        exploit.addModule(ModuleButton("Phase", false))
        exploit.addModule(ModuleButton("Timer", false))
        exploit.addModule(ModuleButton("Disabler", false))
        exploit.addModule(ModuleButton("PingSpoof", false))
        exploit.addModule(ModuleButton("Nuker", false))
        exploit.addModule(ModuleButton("Fucker", false))
        exploit.addModule(ModuleButton("Crasher", false))
        exploit.addModule(ModuleButton("ForceOP", false))
        exploit.addModule(ModuleButton("AutoSign", false))
        exploit.addModule(ModuleButton("Derp", false))
        exploit.addModule(ModuleButton("Clip", false))
        exploit.addModule(ModuleButton("PortalGodMode", false))
        exploit.addModule(ModuleButton("AntiFireball", false))
        exploit.addModule(ModuleButton("Freeze", false))
        exploit.addModule(ModuleButton("PacketFly", false))
        exploit.addModule(ModuleButton("PacketMine", false))
        exploit.addModule(ModuleButton("MultiTask", false))
        exploit.addModule(ModuleButton("NoInteract", false))
        exploit.addModule(ModuleButton("AntiHunger2", false))
        exploit.addModule(ModuleButton("FakePlayer", false))
        categories.add(exploit)
        
        val misc = CategoryPanel("Misc", 5)
        misc.addModule(ModuleButton("AntiBot", false))
        misc.addModule(ModuleButton("Teams", false))
        misc.addModule(ModuleButton("AntiAFK", false))
        misc.addModule(ModuleButton("AutoGG", false))
        misc.addModule(ModuleButton("MiddleClick", false))
        misc.addModule(ModuleButton("NameProtect", false))
        misc.addModule(ModuleButton("Spammer", false))
        misc.addModule(ModuleButton("FakePlayer", false))
        misc.addModule(ModuleButton("Targets", false))
        misc.addModule(ModuleButton("AutoLeave", false))
        misc.addModule(ModuleButton("AutoTip", false))
        misc.addModule(ModuleButton("AutoL", false))
        misc.addModule(ModuleButton("ChatBypass", false))
        misc.addModule(ModuleButton("Notifier", false))
        misc.addModule(ModuleButton("PacketLogger", false))
        misc.addModule(ModuleButton("Teleport", false))
        misc.addModule(ModuleButton("Simulation", false))
        misc.addModule(ModuleButton("AutoReconnect", false))
        misc.addModule(ModuleButton("ServerCrasher", false))
        misc.addModule(ModuleButton("AutoAccept", false))
        misc.addModule(ModuleButton("DiscordRPC", false))
        misc.addModule(ModuleButton("BetterChat", false))
        misc.addModule(ModuleButton("IRC", false))
        misc.addModule(ModuleButton("Announcer", false))
        misc.addModule(ModuleButton("StreamerMode", false))
        categories.add(misc)
        
        val world = CategoryPanel("World", 6)
        world.addModule(ModuleButton("ChestESP", false))
        world.addModule(ModuleButton("SpeedMine", false))
        world.addModule(ModuleButton("AutoTrap", false))
        world.addModule(ModuleButton("AutoCity", false))
        world.addModule(ModuleButton("AutoCrystal", false))
        world.addModule(ModuleButton("AutoWeb", false))
        world.addModule(ModuleButton("Surround", false))
        world.addModule(ModuleButton("HoleFill", false))
        world.addModule(ModuleButton("SelfTrap", false))
        world.addModule(ModuleButton("AntiRegear", false))
        world.addModule(ModuleButton("AutoAnchor", false))
        world.addModule(ModuleButton("BurrowESP", false))
        world.addModule(ModuleButton("AutoBurrow", false))
        world.addModule(ModuleButton("Burrow", false))
        world.addModule(ModuleButton("AntiPiston", false))
        world.addModule(ModuleButton("PistonAura", false))
        world.addModule(ModuleButton("CevBreaker", false))
        world.addModule(ModuleButton("TntAura", false))
        world.addModule(ModuleButton("Offhand", false))
        world.addModule(ModuleButton("XCarry", false))
        world.addModule(ModuleButton("AutoLog", false))
        world.addModule(ModuleButton("AntiAim", false))
        world.addModule(ModuleButton("AutoTNT", false))
        world.addModule(ModuleButton("Quiver", false))
        world.addModule(ModuleButton("PacketMine", false))
        categories.add(world)
    }
    override fun init() {
        super.init()
        val startX = 20; val startY = 55; val spacing = 155; val maxPerRow = 5
        categories.forEachIndexed { index, category ->
            val row = index / maxPerRow; val col = index % maxPerRow
            category.x = startX + col * spacing; category.y = startY + row * 455
        }
    }
    override fun render(context: DrawContext, mouseX: Int, mouseY: Int, delta: Float) {
        animationManager.update()
        context.fill(0, 0, width, height, 0xFF0A0A0A.toInt())
        TopBar.render(context, width, fadeAlpha)
        categories.forEach { it.render(context, mouseX, mouseY, fadeAlpha) }
        super.render(context, mouseX, mouseY, delta)
    }
    override fun mouseClicked(mouseX: Double, mouseY: Double, button: Int): Boolean {
        if (TopBar.handleClick(mouseX.toInt(), mouseY.toInt(), width)) return true
        categories.forEach { category ->
            if (category.handleClick(mouseX.toInt(), mouseY.toInt(), button)) {
                if (category.isDragging) draggedCategory = category
                return true
            }
        }
        return super.mouseClicked(mouseX, mouseY, button)
    }
    override fun mouseDragged(mouseX: Double, mouseY: Double, button: Int, deltaX: Double, deltaY: Double): Boolean {
        if (button == 0) {
            draggedCategory?.updateDrag(mouseX.toInt(), mouseY.toInt())
            categories.forEach { it.handleDrag(mouseX.toInt()) }
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)
    }
    override fun mouseReleased(mouseX: Double, mouseY: Double, button: Int): Boolean {
        if (button == 0) { draggedCategory = null; categories.forEach { it.release() } }
        return super.mouseReleased(mouseX, mouseY, button)
    }
    override fun mouseScrolled(mouseX: Double, mouseY: Double, horizontalAmount: Double, verticalAmount: Double): Boolean {
        categories.forEach { it.handleScroll(mouseX.toInt(), mouseY.toInt(), verticalAmount) }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)
    }
    override fun keyPressed(keyCode: Int, scanCode: Int, modifiers: Int): Boolean {
        categories.forEach { if (it.handleKey(keyCode)) return true }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { UmbrielClient.toggleMenu(); return true }
        return super.keyPressed(keyCode, scanCode, modifiers)
    }
    override fun shouldPause() = false
}

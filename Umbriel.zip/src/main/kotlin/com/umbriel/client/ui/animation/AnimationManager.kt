package com.umbriel.client.ui.animation
class AnimationManager {
    private val animations = mutableListOf<Animation>()
    fun update() { animations.removeIf { it.update() } }
    fun animate(duration: Long, easingFunction: (Float) -> Float = Easing::easeOutCubic, callback: (Float) -> Unit) { animations.add(Animation(duration, callback, easingFunction)) }
}

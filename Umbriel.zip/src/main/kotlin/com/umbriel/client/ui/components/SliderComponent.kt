package com.umbriel.client.ui.components
import com.umbriel.client.ui.animation.Easing
import com.umbriel.client.utils.RenderUtils
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
class SliderComponent(private val name: String, private var value: Float, private val min: Float, private val max: Float, private val step: Float = 0.1f) : UIComponent {
    private var dragging = false
    private var hoverAlpha = 0f
    override fun getHeight() = 30
    override fun render(context: DrawContext, x: Int, y: Int, width: Int, mouseX: Int, mouseY: Int, alpha: Float) {
        val mc = MinecraftClient.getInstance()
        val isHovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + getHeight()
        hoverAlpha = Easing.lerp(hoverAlpha, if (isHovered || dragging) 1f else 0f, 0.15f)
        RenderUtils.drawRoundedRect(context, x, y, width, getHeight(), 8, UColor.withAlpha(UColor.BG_DARK, (alpha * (30 + hoverAlpha * 20)).toInt()))
        context.drawText(mc.textRenderer, "$name:", x + 8, y + 5, UColor.withAlpha(UColor.TEXT_DIM, (alpha * 255).toInt()), false)
        val valueText = "%.1f".format(value)
        context.drawText(mc.textRenderer, valueText, x + width - mc.textRenderer.getWidth(valueText) - 8, y + 5, UColor.withAlpha(UColor.getAccent(), (alpha * 255).toInt()), false)
        val trackX = x + 8
        val trackY = y + 19
        val trackWidth = width - 16
        val trackHeight = 4
        RenderUtils.drawRoundedRect(context, trackX, trackY, trackWidth, trackHeight, 2, UColor.withAlpha(UColor.BG_PANEL, (alpha * 255).toInt()))
        val normalized = ((value - min) / (max - min)).coerceIn(0f, 1f)
        val filledWidth = (trackWidth * normalized).toInt()
        if (filledWidth > 0) {
            RenderUtils.drawRoundedRect(context, trackX, trackY, filledWidth, trackHeight, 2, UColor.withAlpha(UColor.getAccent(), (alpha * 255).toInt()))
            val thumbX = trackX + filledWidth - 5
            RenderUtils.drawRoundedRect(context, thumbX, trackY - 3, 10, 10, 5, UColor.withAlpha(UColor.getAccent(), (alpha * (200 + hoverAlpha * 55)).toInt()))
        }
    }
    override fun handleClick(mouseX: Int, mouseY: Int, x: Int, y: Int, width: Int, button: Int): Boolean {
        if (button == 0 && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + getHeight()) {
            dragging = true
            updateValue(mouseX, x, width)
            return true
        }
        return false
    }
    fun handleDrag(mouseX: Int, x: Int, width: Int) { if (dragging) updateValue(mouseX, x, width) }
    fun release() { dragging = false }
    private fun updateValue(mouseX: Int, x: Int, width: Int) {
        val normalized = ((mouseX - x - 8).toFloat() / (width - 16)).coerceIn(0f, 1f)
        value = ((min + (max - min) * normalized) / step).toInt() * step
        value = value.coerceIn(min, max)
    }
}

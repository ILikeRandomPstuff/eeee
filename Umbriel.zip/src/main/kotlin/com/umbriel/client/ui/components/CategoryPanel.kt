package com.umbriel.client.ui.components
import com.umbriel.client.ui.animation.Easing
import com.umbriel.client.utils.RenderUtils
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
class CategoryPanel(val name: String, private val index: Int) {
    private val modules = mutableListOf<ModuleButton>()
    var collapsed = false
    private var collapseAnimation = 1f
    var x = 0
    var y = 0
    private var scrollOffset = 0f
    private var targetScrollOffset = 0f
    private var dragOffsetX = 0
    private var dragOffsetY = 0
    var isDragging = false
    fun addModule(module: ModuleButton) { modules.add(module) }
    fun getHeight(): Int {
        if (collapseAnimation < 0.01f) return 34
        val contentHeight = modules.sumOf { val baseHeight = 26; if (it.settings.isNotEmpty() && it.expanded) baseHeight + it.settings.sumOf { s -> s.getHeight() + 2 } else baseHeight } + modules.size * 4
        val maxHeight = 400
        return (34 + minOf(contentHeight, maxHeight) * collapseAnimation).toInt()
    }
    fun startDrag(mouseX: Int, mouseY: Int) { isDragging = true; dragOffsetX = mouseX - x; dragOffsetY = mouseY - y }
    fun updateDrag(mouseX: Int, mouseY: Int) { if (isDragging) { x = mouseX - dragOffsetX; y = mouseY - dragOffsetY } }
    fun stopDrag() { isDragging = false }
    fun render(context: DrawContext, mouseX: Int, mouseY: Int, alpha: Float) {
        val mc = MinecraftClient.getInstance()
        val width = 145
        collapseAnimation = Easing.lerp(collapseAnimation, if (collapsed) 0f else 1f, 0.15f)
        val fullHeight = getHeight()
        val headerHeight = 34
        RenderUtils.drawRoundedRect(context, x + 2, y + 2, width, fullHeight, 10, UColor.withAlpha(0x000000, (alpha * 60).toInt()))
        RenderUtils.drawRoundedRect(context, x, y, width, fullHeight, 10, UColor.withAlpha(UColor.BG_PANEL, (alpha * 240).toInt()))
        RenderUtils.drawRoundedRect(context, x, y, width, headerHeight, 10, UColor.withAlpha(UColor.BG_DARK, (alpha * 200).toInt()))
        context.fill(x, y, x + width, y + 3, UColor.withAlpha(UColor.getAccent(), (alpha * 255).toInt()))
        context.drawText(mc.textRenderer, name.uppercase(), x + 10, y + 11, UColor.withAlpha(UColor.TEXT, (alpha * 255).toInt()), false)
        context.drawText(mc.textRenderer, "${modules.size} modules", x + 10, y + 21, UColor.withAlpha(UColor.TEXT_DIM, (alpha * 180).toInt()), false)
        val collapseX = x + width - 20
        val collapseY = y + 11
        RenderUtils.drawRoundedRect(context, collapseX, collapseY, 14, 14, 7, UColor.withAlpha(UColor.BG_HOVER, (alpha * 100).toInt()))
        val arrowColor = UColor.withAlpha(UColor.TEXT, (alpha * 200).toInt())
        if (collapsed) context.fill(collapseX + 6, collapseY + 3, collapseX + 7, collapseY + 11, arrowColor)
        else context.fill(collapseX + 3, collapseY + 6, collapseX + 11, collapseY + 7, arrowColor)
        if (collapseAnimation > 0.01f) {
            scrollOffset = Easing.lerp(scrollOffset, targetScrollOffset, 0.2f)
            var moduleY = y + headerHeight + 5 + scrollOffset.toInt()
            val clipY = y + headerHeight
            val clipHeight = fullHeight - headerHeight
            val contentHeight = modules.sumOf { val baseHeight = 26; if (it.settings.isNotEmpty() && it.expanded) baseHeight + it.settings.sumOf { s -> s.getHeight() + 2 } else baseHeight } + modules.size * 4
            modules.forEach { module ->
                if (moduleY + 26 > clipY && moduleY < clipY + clipHeight) {
                    val moduleAlpha = alpha * collapseAnimation
                    val moduleHeight = module.render(context, x + 7, moduleY, width - 14, mouseX, mouseY, moduleAlpha)
                    moduleY += (moduleHeight + 4).coerceAtLeast(1)
                } else moduleY += (26 + 4)
            }
            if (contentHeight > clipHeight) {
                val scrollbarX = x + width - 5
                val scrollbarWidth = 3
                val scrollbarHeight = ((clipHeight.toFloat() / contentHeight) * clipHeight).toInt().coerceAtLeast(20)
                val scrollbarY = y + headerHeight + ((-scrollOffset / contentHeight) * clipHeight).toInt()
                RenderUtils.drawRoundedRect(context, scrollbarX, scrollbarY, scrollbarWidth, scrollbarHeight, 2, UColor.withAlpha(UColor.getAccent(), (alpha * 200).toInt()))
            }
        }
    }
    fun handleClick(mouseX: Int, mouseY: Int, button: Int): Boolean {
        val width = 145
        val headerHeight = 34
        val collapseX = x + width - 20
        val collapseY = y + 11
        if (button == 0 && mouseX >= collapseX && mouseX <= collapseX + 14 && mouseY >= collapseY && mouseY <= collapseY + 14) {
            collapsed = !collapsed
            return true
        }
        if (button == 0 && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + headerHeight) {
            startDrag(mouseX, mouseY)
            return true
        }
        if (!collapsed && collapseAnimation > 0.5f) {
            var moduleY = y + headerHeight + 5 + scrollOffset.toInt()
            modules.forEach { module ->
                val moduleHeight = if (module.settings.isNotEmpty() && module.expanded) 26 + module.settings.sumOf { it.getHeight() + 2 } else 26
                if (module.handleClick(mouseX, mouseY, x + 7, moduleY, width - 14, button)) return true
                moduleY += moduleHeight + 4
            }
        }
        return false
    }
    fun handleScroll(mouseX: Int, mouseY: Int, amount: Double) {
        val width = 145
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + getHeight()) {
            val contentHeight = modules.sumOf { if (it.settings.isNotEmpty() && it.expanded) 26 + it.settings.sumOf { s -> s.getHeight() + 2 } else 26 } + modules.size * 4
            val visibleHeight = getHeight() - 34
            val maxScroll = (contentHeight - visibleHeight).coerceAtLeast(0)
            targetScrollOffset = (targetScrollOffset + amount.toFloat() * 25).coerceIn(-maxScroll.toFloat(), 0f)
        }
    }
    fun handleKey(keyCode: Int): Boolean {
        modules.forEach { if (it.handleKey(keyCode)) return true }
        return false
    }
    fun handleDrag(mouseX: Int) { if (!collapsed) modules.forEach { it.handleDrag(mouseX, x + 7, 145 - 14) } }
    fun release() { stopDrag(); if (!collapsed) modules.forEach { it.release() } }
}

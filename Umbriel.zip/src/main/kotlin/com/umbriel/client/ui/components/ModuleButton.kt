package com.umbriel.client.ui.components
import com.umbriel.client.ui.animation.Easing
import com.umbriel.client.utils.RenderUtils
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
import org.lwjgl.glfw.GLFW
class ModuleButton(private val name: String, private var enabled: Boolean, val settings: MutableList<UIComponent> = mutableListOf()) {
    private var hoverAlpha = 0f
    private var toggleAnimation = if (enabled) 1f else 0f
    var expanded = false
    private var expandAnimation = 0f
    var keybind: Int = GLFW.GLFW_KEY_UNKNOWN
    private var listeningForKey = false
    fun render(context: DrawContext, x: Int, y: Int, width: Int, mouseX: Int, mouseY: Int, alpha: Float): Int {
        val mc = MinecraftClient.getInstance()
        val baseHeight = 26
        val isHovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + baseHeight
        hoverAlpha = Easing.lerp(hoverAlpha, if (isHovered) 1f else 0f, 0.15f)
        toggleAnimation = Easing.lerp(toggleAnimation, if (enabled) 1f else 0f, 0.12f)
        expandAnimation = Easing.lerp(expandAnimation, if (expanded) 1f else 0f, 0.18f)
        val bgColor = UColor.interpolate(UColor.BG_HOVER, UColor.getAccentDark(), toggleAnimation * 0.3f)
        RenderUtils.drawRoundedRect(context, x, y, width, baseHeight, 13, UColor.withAlpha(bgColor, (alpha * (40 + hoverAlpha * 60)).toInt()))
        if (toggleAnimation > 0.01f) {
            val barWidth = (4 * toggleAnimation).toInt()
            context.fill(x + 3, y + 6, x + 3 + barWidth, y + baseHeight - 6, UColor.withAlpha(UColor.getAccent(), (alpha * 255 * toggleAnimation).toInt()))
        }
        val textColor = UColor.interpolate(UColor.TEXT_DIM, UColor.TEXT, toggleAnimation)
        context.drawText(mc.textRenderer, name, x + 10, y + 9, UColor.withAlpha(textColor, (alpha * 255).toInt()), false)
        if (listeningForKey) {
            val listening = "..."
            context.drawText(mc.textRenderer, listening, x + width - mc.textRenderer.getWidth(listening) - 8, y + 9, UColor.withAlpha(UColor.getAccent(), (alpha * 255).toInt()), false)
        } else if (keybind != GLFW.GLFW_KEY_UNKNOWN) {
            val keyName = GLFW.glfwGetKeyName(keybind, 0)?.uppercase() ?: "?"
            context.drawText(mc.textRenderer, keyName, x + width - mc.textRenderer.getWidth(keyName) - 8, y + 9, UColor.withAlpha(UColor.TEXT_DIM, (alpha * 180).toInt()), false)
        }
        val indicatorX = x + width - 18
        val indicatorSize = 8
        RenderUtils.drawRoundedRect(context, indicatorX, y + 9, indicatorSize, indicatorSize, 4, UColor.withAlpha(UColor.getAccent(), (alpha * (100 + toggleAnimation * 155)).toInt()))
        if (settings.isNotEmpty()) {
            val arrowX = x + width - 28
            val arrowColor = UColor.withAlpha(UColor.TEXT_DIM, (alpha * 200).toInt())
            if (expandAnimation < 0.5f) context.fill(arrowX, y + 11, arrowX + 4, y + 12, arrowColor)
            else context.fill(arrowX + 1, y + 10, arrowX + 2, y + 14, arrowColor)
        }
        var totalHeight = baseHeight
        if (expandAnimation > 0.01f && settings.isNotEmpty()) {
            var settingY = y + baseHeight + 2
            settings.forEach { setting ->
                val settingHeight = setting.getHeight()
                val settingAlpha = alpha * expandAnimation
                if (expandAnimation > 0.01f) {
                    setting.render(context, x + 8, settingY, width - 16, mouseX, mouseY, settingAlpha)
                    settingY += ((settingHeight + 2) * expandAnimation).toInt()
                }
            }
            totalHeight += (settings.sumOf { it.getHeight() + 2 } * expandAnimation).toInt()
        }
        return totalHeight
    }
    fun handleClick(mouseX: Int, mouseY: Int, x: Int, y: Int, width: Int, button: Int): Boolean {
        val baseHeight = 26
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + baseHeight) {
            if (button == 0) {
                if (settings.isNotEmpty() && mouseX >= x + width - 30) expanded = !expanded
                else enabled = !enabled
            } else if (button == 1) {
                expanded = !expanded
            }
            return true
        }
        if (expanded && expandAnimation > 0.5f) {
            var settingY = y + baseHeight + 2
            settings.forEach { setting ->
                val settingHeight = setting.getHeight()
                if (setting.handleClick(mouseX, mouseY, x + 8, settingY, width - 16, button)) return true
                settingY += ((settingHeight + 2) * expandAnimation).toInt()
            }
        }
        return false
    }
    fun handleKey(keyCode: Int): Boolean {
        if (listeningForKey) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { keybind = GLFW.GLFW_KEY_UNKNOWN }
            else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) { keybind = GLFW.GLFW_KEY_UNKNOWN }
            else { keybind = keyCode }
            listeningForKey = false
            return true
        }
        return false
    }
    fun startKeyListen() { listeningForKey = true }
    fun handleDrag(mouseX: Int, x: Int, width: Int) { if (expanded) settings.forEach { if (it is SliderComponent) it.handleDrag(mouseX, x + 8, width - 16) } }
    fun release() { settings.forEach { if (it is SliderComponent) it.release() } }
}

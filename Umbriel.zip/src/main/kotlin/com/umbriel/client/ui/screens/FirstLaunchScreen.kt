package com.umbriel.client.ui.screens
import com.umbriel.client.ui.animation.AnimationManager
import com.umbriel.client.ui.animation.Easing
import com.umbriel.client.ui.components.UColor
import com.umbriel.client.utils.ConfigManager
import net.minecraft.client.gui.DrawContext
import net.minecraft.client.gui.screen.Screen
import net.minecraft.client.render.RenderLayer
import net.minecraft.text.Text
import net.minecraft.util.Identifier
import org.lwjgl.glfw.GLFW
class FirstLaunchScreen : Screen(Text.literal("Umbriel")) {
    private val animationManager = AnimationManager()
    private var fadeAlpha = 0f
    private var logoAlpha = 0f
    private var logoScale = 0.8f
    private var textAlpha = 0f
    private var textX = -200f
    private val startTime = System.currentTimeMillis()
    private var logoShown = false
    private var canClose = false
    private val logoTexture = Identifier.of("umbriel", "textures/logo.png")
    init { animationManager.animate(600, Easing::easeOutCubic) { fadeAlpha = it; logoAlpha = it; logoScale = 0.8f + it * 0.2f } }
    override fun render(context: DrawContext, mouseX: Int, mouseY: Int, delta: Float) {
        animationManager.update()
        val currentTime = System.currentTimeMillis() - startTime
        context.fill(0, 0, width, height, UColor.withAlpha(0x0A0A0A, 255))
        val centerX = width / 2
        val centerY = height / 2
        val logoSize = (100 * logoScale).toInt()
        val logoX = centerX - logoSize - 20
        val logoY = centerY - logoSize / 2
        context.matrices.push()
        context.matrices.translate(logoX.toFloat() + logoSize / 2f, logoY.toFloat() + logoSize / 2f, 0f)
        context.matrices.scale(logoScale, logoScale, 1f)
        context.matrices.translate(-logoSize / 2f, -logoSize / 2f, 0f)
        try { context.drawTexture({ id -> RenderLayer.getGuiTexturedOverlay(id) }, logoTexture, 0, 0, 0f, 0f, logoSize, logoSize, logoSize, logoSize) }
        catch (e: Exception) { context.fill(0, 0, logoSize, logoSize, UColor.withAlpha(UColor.getAccent(), (logoAlpha * 100).toInt())) }
        context.matrices.pop()
        if (currentTime > 600 && !logoShown) {
            logoShown = true
            animationManager.animate(800, Easing::easeOutBack) { progress -> textAlpha = progress; textX = -200f + progress * 200f }
            animationManager.animate(2000) { canClose = true }
        }
        if (textAlpha > 0.01f) {
            val textPosX = (centerX + textX).toInt()
            val textPosY = centerY - 10
            context.matrices.push()
            context.matrices.scale(2.5f, 2.5f, 1f)
            val scaledX = (textPosX / 2.5f).toInt()
            val scaledY = (textPosY / 2.5f).toInt()
            context.drawText(textRenderer, "MBRIEL", scaledX + 1, scaledY + 1, UColor.withAlpha(0x000000, (textAlpha * 120).toInt()), false)
            context.drawText(textRenderer, "MBRIEL", scaledX, scaledY, UColor.withAlpha(UColor.getAccent(), (textAlpha * 255).toInt()), false)
            context.matrices.pop()
            if (canClose) {
                val subtitle = "Press ESC or Click to Continue"
                val subX = centerX - textRenderer.getWidth(subtitle) / 2
                context.drawText(textRenderer, subtitle, subX, textPosY + 50, UColor.withAlpha(UColor.TEXT_DIM, (textAlpha * 200).toInt()), false)
            }
        }
        super.render(context, mouseX, mouseY, delta)
    }
    override fun keyPressed(keyCode: Int, scanCode: Int, modifiers: Int): Boolean {
        if ((keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) && canClose) { ConfigManager.setFirstLaunchComplete(); client?.setScreen(UmbrielMenuScreen()); return true }
        return super.keyPressed(keyCode, scanCode, modifiers)
    }
    override fun mouseClicked(mouseX: Double, mouseY: Double, button: Int): Boolean {
        if (canClose) { ConfigManager.setFirstLaunchComplete(); client?.setScreen(UmbrielMenuScreen()); return true }
        return super.mouseClicked(mouseX, mouseY, button)
    }
    override fun shouldPause() = false
}

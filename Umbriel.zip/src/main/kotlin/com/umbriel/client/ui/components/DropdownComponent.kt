package com.umbriel.client.ui.components
import com.umbriel.client.ui.animation.Easing
import com.umbriel.client.utils.RenderUtils
import net.minecraft.client.MinecraftClient
import net.minecraft.client.gui.DrawContext
class DropdownComponent(private val name: String, private val options: List<String>, private var selectedIndex: Int = 0) : UIComponent {
    private var expanded = false
    private var expandAnimation = 0f
    private var hoverAlpha = 0f
    override fun getHeight() = if (expandAnimation > 0.01f) (22 + options.size * 20 * expandAnimation).toInt() else 22
    override fun render(context: DrawContext, x: Int, y: Int, width: Int, mouseX: Int, mouseY: Int, alpha: Float) {
        val mc = MinecraftClient.getInstance()
        val baseHeight = 22
        expandAnimation = Easing.lerp(expandAnimation, if (expanded) 1f else 0f, 0.18f)
        val isMainHovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + baseHeight
        hoverAlpha = Easing.lerp(hoverAlpha, if (isMainHovered) 1f else 0f, 0.15f)
        RenderUtils.drawRoundedRect(context, x, y, width, baseHeight, 8, UColor.withAlpha(UColor.BG_DARK, (alpha * (40 + hoverAlpha * 20)).toInt()))
        context.drawText(mc.textRenderer, "$name:", x + 8, y + 7, UColor.withAlpha(UColor.TEXT_DIM, (alpha * 255).toInt()), false)
        val valueText = options[selectedIndex]
        context.drawText(mc.textRenderer, valueText, x + width - mc.textRenderer.getWidth(valueText) - 16, y + 7, UColor.withAlpha(UColor.getAccent(), (alpha * 255).toInt()), false)
        if (expandAnimation > 0.01f) {
            val dropdownY = y + baseHeight
            options.forEachIndexed { index, option ->
                val optionY = dropdownY + (index * 20 * expandAnimation).toInt()
                val optionHeight = (20 * expandAnimation).toInt()
                val isOptionHovered = expanded && mouseX >= x && mouseX <= x + width && mouseY >= optionY && mouseY < optionY + optionHeight
                val optionBgColor = if (isOptionHovered) UColor.BG_HOVER else if (index == selectedIndex) UColor.BG_PANEL else UColor.BG_DARK
                RenderUtils.drawRoundedRect(context, x, optionY, width, optionHeight, 6, UColor.withAlpha(optionBgColor, (alpha * expandAnimation * 200).toInt()))
                if (index == selectedIndex) context.fill(x, optionY, x + 3, optionY + optionHeight, UColor.withAlpha(UColor.getAccent(), (alpha * expandAnimation * 255).toInt()))
                val textColor = if (index == selectedIndex) UColor.getAccent() else UColor.TEXT
                context.drawText(mc.textRenderer, option, x + 8, optionY + 6, UColor.withAlpha(textColor, (alpha * expandAnimation * 255).toInt()), false)
            }
        }
    }
    override fun handleClick(mouseX: Int, mouseY: Int, x: Int, y: Int, width: Int, button: Int): Boolean {
        if (button != 0) return false
        val baseHeight = 22
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + baseHeight) {
            expanded = !expanded
            return true
        }
        if (expanded && expandAnimation > 0.5f) {
            val dropdownY = y + baseHeight
            options.forEachIndexed { index, _ ->
                val optionY = dropdownY + (index * 20 * expandAnimation).toInt()
                val optionHeight = (20 * expandAnimation).toInt()
                if (mouseX >= x && mouseX <= x + width && mouseY >= optionY && mouseY < optionY + optionHeight) {
                    selectedIndex = index
                    expanded = false
                    return true
                }
            }
        }
        return false
    }
}

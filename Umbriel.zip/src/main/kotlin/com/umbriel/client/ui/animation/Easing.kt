package com.umbriel.client.ui.animation
import kotlin.math.pow
object Easing {
    fun easeOutCubic(t: Float) = ((t - 1f).pow(3) + 1f)
    fun easeInOutQuad(t: Float) = if (t < 0.5f) 2f * t * t else -1f + (4f - 2f * t) * t
    fun easeOutBack(t: Float): Float { val c = 1.70158f; val c3 = c + 1f; return 1f + c3 * (t - 1f).pow(3) + c * (t - 1f).pow(2) }
    fun lerp(start: Float, end: Float, alpha: Float) = start + (end - start) * alpha
}

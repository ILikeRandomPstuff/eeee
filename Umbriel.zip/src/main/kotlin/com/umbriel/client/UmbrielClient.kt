package com.umbriel.client
import com.umbriel.client.utils.ConfigManager
import net.minecraft.client.MinecraftClient
import net.minecraft.client.option.KeyBinding
import net.minecraft.client.util.InputUtil
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper
import org.lwjgl.glfw.GLFW
object UmbrielClient {
    var isMenuOpen = false
    lateinit var menuKeyBinding: KeyBinding
    var showWatermark = true
    var fontScale = 1.0f
    fun initialize() { ConfigManager.init(); menuKeyBinding = KeyBindingHelper.registerKeyBinding(KeyBinding("key.umbriel.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.umbriel.main")); println("[Umbriel] Initialized") }
    fun toggleMenu() {
        val mc = MinecraftClient.getInstance()
        if (ConfigManager.isFirstLaunch() && !isMenuOpen) { mc.setScreen(com.umbriel.client.ui.screens.FirstLaunchScreen()); isMenuOpen = true; return }
        if (isMenuOpen) { mc.setScreen(null); isMenuOpen = false } else { mc.setScreen(com.umbriel.client.ui.screens.UmbrielMenuScreen()); isMenuOpen = true }
    }
    fun panic() { println("[Umbriel] Panic"); isMenuOpen = false; MinecraftClient.getInstance().setScreen(null) }
}

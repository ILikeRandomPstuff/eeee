package com.umbriel.client
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
object UmbrielClientInit : ClientModInitializer {
    override fun onInitializeClient() { UmbrielClient.initialize(); ClientTickEvents.END_CLIENT_TICK.register { while (UmbrielClient.menuKeyBinding.wasPressed()) UmbrielClient.toggleMenu() } }
}

# Umbriel v2.0 - ADVANCED
150+ modules, scrollbars, smooth rounded UI, right-click expand, keybinds
Build: ./gradlew build | Run: ./gradlew runClient | Open: Right Shift
